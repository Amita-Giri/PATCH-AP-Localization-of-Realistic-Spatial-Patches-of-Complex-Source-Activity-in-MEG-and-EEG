all_solvers = [ "MUSIC", "RAP-MUSIC", "TRAP-MUSIC", "FLEX-MUSIC", "FLEX-AP", "AP", "FLEX-SSM", "SSM", 
               "MNE", "wMNE", "dSPM", "FISTA", "L1L2", "GPT",
               "LORETA", "sLORETA", "eLORETA", 
               "LAURA", "Backus-Gilbert", 
               "S-MAP",
               "Champagne", "Low SNR Champagne", "EM Champagne", "MM Champagne", "Convexity Champagne", "MacKay Champagne", "HS Champagne", "FUN",
               "BCS", "Gamma-MAP", "Source-MAP", "Gamma-MAP-MSP", "Source-MAP-MSP",
               "MVAB", "LCMV", "SMV", "WNMV", "HOCMV", "ESMV", "MCMV", "HOCMCMV", "ReciPSIICOS", "SAM",
               "CovCNN","FC", "LSTM", "CNN",
               "OMP", "COSAMP", "SOMP", "REMBO", "SP", "SSP",
               "SMP", "SSMP", "SubSMP",
               "EPIFOCUS",
                
            ]